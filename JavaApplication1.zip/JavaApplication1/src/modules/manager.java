/*
 * The Inventory object for handling new inventory.
 */
package modules;


/**
 *
 * @author riquigley
 */
public class manager {
   
    public manager() {
        System.out.println("Manager Module Loaded");
    }

   /*
    * Called when an Employee has been added 
    */
    public void addEmployee() {
        // An item has been added to the ticket. Fire an event and let everyone know.
        System.out.println("Employee has been added.");
    }

   /*
    * Called when an Employee has been removed
    */
    public void removeEmployee() {
        System.out.println("employee has been removed.");
    }
        
    }

