/*
 * The Inventory object for handling new inventory.
 */
package modules;


/**
 *
 * @author riquigley
 */
public class employee {
   
    public employee() {
        System.out.println("Employee Module Loaded");
    }

   /*
    * Called when an Customer has been added
    */
    public void addCustomer() {
        // Customer has been added to the ticket. Fire an event and let everyone know.
        System.out.println("Customer has been added.");
    }

   /*
    * Called when an Customer has been remoed 
    */
    public void removeCustomer() {
        System.out.println("Customer has been removed.");
    }
        
    }

