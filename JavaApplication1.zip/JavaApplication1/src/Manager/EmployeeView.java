package Manager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yiheng JIang
 */
public class EmployeeView {


   public void printCustomerinformation(String Name, int ID,String town ,String street,String Password,String Postcode,String Username){
      
     
      System.out.println("Customer information"+": ");
      System.out.println("Name: " + Name);
      System.out.println("ID Number: " + ID);
      System.out.println("Street: "+street);
      System.out.println("Town: "+town);
      System.out.println("Username: "+Username);
      System.out.println("Password: "+Password);
      System.out.println("Postcode: "+Postcode);
      
     
      }
}
    

